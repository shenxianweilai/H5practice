For the Canvas 2D chapter you'll all the files you need to run Canvas Ricochet.
To run the application simply open the index.html file in Google Chrome on a desktop.

Contents:
- Canvas Ricochet: Complete game with all necessary files.