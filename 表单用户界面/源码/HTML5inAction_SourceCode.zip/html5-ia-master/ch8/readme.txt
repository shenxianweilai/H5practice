NOTE: The videos used in this example were filmed on top of a hill with a phone, consequently there is a lot of wind noise.
