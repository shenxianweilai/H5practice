For chapter 7 you'll find Wilson's demo and SVG Aliens in their corresponding folders.
To run one of the folders, 

Contents:
- SVG Aliens: An arcade style space shooter that pits players against an evil alien menace. Play it by opening index.html in Google Chrome. Functionality with other browsers not guaranteed.
- Wilson: Demonstrates SVG's size flexibility with in-browser graphics. Uses a *.svg file that should be opened with the latest version of Firefox, Google Chrome, or Opera.